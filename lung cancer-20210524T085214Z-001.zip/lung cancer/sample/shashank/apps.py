from django.apps import AppConfig


class ShashankConfig(AppConfig):
    name = 'shashank'
